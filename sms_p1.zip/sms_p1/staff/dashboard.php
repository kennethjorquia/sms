<?php

include 'upper.php';
?>

<section class="home-section ms-3">
  <!-------------------------------------------------------------------------edit here---------------------------------------------------------------------------------------- -->
<div class="card p-3 border-0 mb-3 rounded-0 shadow">
 <div class="card-body">
  <div class="page-breadcrumb border-bottom border-secondary">
                <div class="row align-items-center">
                    <div class="col-5">
                      <div class="d-flex align-items-start">
                        <ion-icon class="me-2" size="large" style="color:#4040a1" name="grid-sharp"></ion-icon>
                        <h4 class="text-dark fw-bold">Dashboard</h4>
                      </div>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="studDashboard.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>


  <!-- -----------------------------------------------------------------------edit here---------------------------------------------------------------------------------------- -->

</section>
<?php
include("lower.php");
?>