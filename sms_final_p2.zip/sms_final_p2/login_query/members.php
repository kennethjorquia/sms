<?php  

if (isset($_SESSION['username']) && isset($_SESSION['log_id'])) {
    
    $sql = "SELECT * FROM guidance_users ORDER BY log_id ASC";
    $res = mysqli_query($conn, $sql);
}else{
	header("Location: index.php");
} 